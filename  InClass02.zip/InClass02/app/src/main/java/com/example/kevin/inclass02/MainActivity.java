package com.example.kevin.inclass02;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import static android.app.ProgressDialog.show;

public class MainActivity extends AppCompatActivity {
    TextView seekmoodValue;
    public int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        final ImageView man1 = findViewById(R.id.man1);
        final ImageView man2 = findViewById(R.id.man2);
        ImageView man3 = findViewById(R.id.man3);
        ImageView woman1 = findViewById(R.id.woman1);
        ImageView woman2 = findViewById(R.id.woman3);
        ImageView woman3 = findViewById(R.id.woman2);
        final SeekBar seekBar = (SeekBar) findViewById(R.id.seek_bar);
        seekBar.setProgress(0);
        seekBar.incrementProgressBy(1);
        seekBar.setMax(4);
        ImageView seekMoodValue = (ImageView) findViewById(R.id.imageView2);

        seekMoodValue  = (ImageView) findViewById(R.id.imageView2);



        final ImageView finalSeekMoodValue = seekMoodValue;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                progress = progress /1;
                progress = progress * 1;

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    findViewById(R.id.select_avatar).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, SelectAvatar.class);
            startActivity(intent);
            final ImageView selectAvatar = (ImageView) findViewById(R.id.select_avatar);
            final ImageView selectAvatar1 = (ImageView) findViewById(R.id.select_avatar);
            final ImageView selectAvatar2 = (ImageView) findViewById(R.id.select_avatar);
            final ImageView selectAvatar3 = (ImageView) findViewById(R.id.select_avatar);
            final ImageView selectAvatar4 = (ImageView) findViewById(R.id.select_avatar);
            final ImageView selectAvatar5 = (ImageView) findViewById(R.id.select_avatar);
            final ImageView selectAvatar6 = (ImageView) findViewById(R.id.select_avatar);
           selectAvatar.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   selectAvatar.setImageResource(R.drawable.avatar_m_1);
               }
           });
            selectAvatar1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectAvatar1.setImageResource(R.drawable.avatar_m_2);
                }
            });
            selectAvatar2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectAvatar2.setImageResource(R.drawable.avatar_m_3);
                }
            });
            selectAvatar4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectAvatar4.setImageResource(R.drawable.avatar_f_1);
                }
            });
            selectAvatar5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectAvatar5.setImageResource(R.drawable.avatar_f_2);
                }
            });
            selectAvatar6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectAvatar6.setImageResource(R.drawable.avatar_f_3);
                }
            });





        }


    });
    findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent submit = new Intent(MainActivity.this, com.example.kevin.inclass02.submit.class);
            startActivity(submit);
        }
    });


    }
}
