package com.example.kevin.inclass02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class SelectAvatar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_avatar);
        final ImageView man1 = findViewById(R.id.man1);
        ImageView man2 = findViewById(R.id.man2);
        ImageView man3 = findViewById(R.id.man3);
        ImageView woman1 = findViewById(R.id.woman1);
        ImageView woman2 = findViewById(R.id.woman3);
        ImageView woman3 = findViewById(R.id.woman2);
        final ImageView selectAvatar = findViewById(R.id.select_avatar);
        man1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             finish();
            }
        });
        man2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        man3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        woman1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        woman2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        woman3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
